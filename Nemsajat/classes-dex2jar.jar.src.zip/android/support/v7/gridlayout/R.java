package android.support.v7.gridlayout;

public final class R
{
  public static final class attr
  {
    public static final int alignmentMode = 2130772014;
    public static final int columnCount = 2130772012;
    public static final int columnOrderPreserved = 2130772016;
    public static final int layout_column = 2130772019;
    public static final int layout_columnSpan = 2130772020;
    public static final int layout_gravity = 2130772021;
    public static final int layout_row = 2130772017;
    public static final int layout_rowSpan = 2130772018;
    public static final int orientation = 2130772010;
    public static final int rowCount = 2130772011;
    public static final int rowOrderPreserved = 2130772015;
    public static final int useDefaultMargins = 2130772013;
  }
  
  public static final class dimen
  {
    public static final int default_gap = 2131427328;
  }
  
  public static final class id
  {
    public static final int alignBounds = 2131230764;
    public static final int alignMargins = 2131230765;
    public static final int bottom = 2131230767;
    public static final int center = 2131230774;
    public static final int center_horizontal = 2131230772;
    public static final int center_vertical = 2131230770;
    public static final int clip_horizontal = 2131230777;
    public static final int clip_vertical = 2131230776;
    public static final int end = 2131230779;
    public static final int fill = 2131230775;
    public static final int fill_horizontal = 2131230773;
    public static final int fill_vertical = 2131230771;
    public static final int horizontal = 2131230762;
    public static final int left = 2131230768;
    public static final int right = 2131230769;
    public static final int start = 2131230778;
    public static final int top = 2131230766;
    public static final int vertical = 2131230763;
  }
  
  public static final class styleable
  {
    public static final int[] GridLayout = { 2130772010, 2130772011, 2130772012, 2130772013, 2130772014, 2130772015, 2130772016 };
    public static final int[] GridLayout_Layout = { 16842996, 16842997, 16842998, 16842999, 16843000, 16843001, 16843002, 2130772017, 2130772018, 2130772019, 2130772020, 2130772021 };
    public static final int GridLayout_Layout_android_layout_height = 1;
    public static final int GridLayout_Layout_android_layout_margin = 2;
    public static final int GridLayout_Layout_android_layout_marginBottom = 6;
    public static final int GridLayout_Layout_android_layout_marginLeft = 3;
    public static final int GridLayout_Layout_android_layout_marginRight = 5;
    public static final int GridLayout_Layout_android_layout_marginTop = 4;
    public static final int GridLayout_Layout_android_layout_width = 0;
    public static final int GridLayout_Layout_layout_column = 9;
    public static final int GridLayout_Layout_layout_columnSpan = 10;
    public static final int GridLayout_Layout_layout_gravity = 11;
    public static final int GridLayout_Layout_layout_row = 7;
    public static final int GridLayout_Layout_layout_rowSpan = 8;
    public static final int GridLayout_alignmentMode = 4;
    public static final int GridLayout_columnCount = 2;
    public static final int GridLayout_columnOrderPreserved = 6;
    public static final int GridLayout_orientation = 0;
    public static final int GridLayout_rowCount = 1;
    public static final int GridLayout_rowOrderPreserved = 5;
    public static final int GridLayout_useDefaultMargins = 3;
  }
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\android\support\v7\gridlayout\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */