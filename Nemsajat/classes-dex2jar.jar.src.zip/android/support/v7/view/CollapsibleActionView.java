package android.support.v7.view;

public abstract interface CollapsibleActionView
{
  public abstract void onActionViewCollapsed();
  
  public abstract void onActionViewExpanded();
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\android\support\v7\view\CollapsibleActionView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */