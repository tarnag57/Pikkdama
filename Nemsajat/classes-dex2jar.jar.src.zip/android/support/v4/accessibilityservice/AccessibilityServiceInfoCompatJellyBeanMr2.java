package android.support.v4.accessibilityservice;

import android.accessibilityservice.AccessibilityServiceInfo;

class AccessibilityServiceInfoCompatJellyBeanMr2
{
  public static int getCapabilities(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return paramAccessibilityServiceInfo.getCapabilities();
  }
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\accessibilityservice\AccessibilityServiceInfoCompatJellyBeanMr2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */