package com.google.ads.mediation.customevent;

@Deprecated
public abstract interface CustomEventInterstitialListener
  extends CustomEventListener
{
  public abstract void onReceivedAd();
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\com\google\ads\mediation\customevent\CustomEventInterstitialListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */