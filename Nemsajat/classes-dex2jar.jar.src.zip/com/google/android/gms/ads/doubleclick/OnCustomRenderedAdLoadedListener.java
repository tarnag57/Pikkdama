package com.google.android.gms.ads.doubleclick;

public abstract interface OnCustomRenderedAdLoadedListener
{
  public abstract void onCustomRenderedAdLoaded(CustomRenderedAd paramCustomRenderedAd);
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\ads\doubleclick\OnCustomRenderedAdLoadedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */