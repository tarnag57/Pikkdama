package com.google.android.gms.ads.doubleclick;

public abstract interface AppEventListener
{
  public abstract void onAppEvent(String paramString1, String paramString2);
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\ads\doubleclick\AppEventListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */