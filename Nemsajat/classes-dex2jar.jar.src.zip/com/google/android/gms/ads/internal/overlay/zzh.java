package com.google.android.gms.ads.internal.overlay;

public abstract interface zzh
{
  public abstract void onPaused();
  
  public abstract void zzfn();
  
  public abstract void zzfo();
  
  public abstract void zzfp();
  
  public abstract void zzfq();
  
  public abstract void zzfr();
  
  public abstract void zzg(String paramString1, String paramString2);
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */