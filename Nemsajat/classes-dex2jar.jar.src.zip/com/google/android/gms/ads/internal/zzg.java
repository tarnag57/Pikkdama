package com.google.android.gms.ads.internal;

import android.view.View;

public abstract interface zzg
{
  public abstract void recordClick();
  
  public abstract void recordImpression();
  
  public abstract void zzc(View paramView);
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\ads\internal\zzg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */