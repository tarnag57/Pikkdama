package com.google.android.gms.ads.internal.overlay;

public abstract interface zzn
{
  public abstract void zzaQ();
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\ads\internal\overlay\zzn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */