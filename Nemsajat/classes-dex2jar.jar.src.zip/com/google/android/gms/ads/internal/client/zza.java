package com.google.android.gms.ads.internal.client;

public abstract interface zza
{
  public abstract void onAdClicked();
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\ads\internal\client\zza.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */