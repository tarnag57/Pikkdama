package com.google.android.gms.ads.internal.client;

import com.google.android.gms.internal.zzha;

@zzha
public class zzac
{
  public String getTrackingId()
  {
    return null;
  }
  
  public boolean isGoogleAnalyticsEnabled()
  {
    return false;
  }
  
  public void zzO(String paramString) {}
  
  public void zzm(boolean paramBoolean) {}
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzac.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */