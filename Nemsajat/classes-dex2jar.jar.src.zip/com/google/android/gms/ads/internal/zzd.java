package com.google.android.gms.ads.internal;

import com.google.android.gms.ads.internal.overlay.zzj;
import com.google.android.gms.ads.internal.overlay.zzl;
import com.google.android.gms.internal.zzdi;
import com.google.android.gms.internal.zzdy;
import com.google.android.gms.internal.zzha;

@zzha
public class zzd
{
  public final zzdy zzpm;
  public final zzj zzpn;
  
  public zzd(zzdy paramzzdy, zzj paramzzj)
  {
    this.zzpm = paramzzdy;
    this.zzpn = paramzzj;
  }
  
  public static zzd zzbf()
  {
    return new zzd(new zzdi(), new zzl());
  }
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\ads\internal\zzd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */