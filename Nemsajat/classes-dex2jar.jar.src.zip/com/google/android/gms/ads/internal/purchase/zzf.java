package com.google.android.gms.ads.internal.purchase;

import com.google.android.gms.internal.zzha;

@zzha
public final class zzf
{
  public long zzEO;
  public final String zzEP;
  public final String zzEQ;
  
  public zzf(long paramLong, String paramString1, String paramString2)
  {
    this.zzEO = paramLong;
    this.zzEQ = paramString1;
    this.zzEP = paramString2;
  }
  
  public zzf(String paramString1, String paramString2)
  {
    this(-1L, paramString1, paramString2);
  }
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\ads\internal\purchase\zzf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */