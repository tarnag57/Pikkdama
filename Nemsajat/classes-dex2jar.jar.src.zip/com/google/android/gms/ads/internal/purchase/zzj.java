package com.google.android.gms.ads.internal.purchase;

import android.content.Intent;

public abstract interface zzj
{
  public abstract void zza(String paramString, boolean paramBoolean, int paramInt, Intent paramIntent, zzf paramzzf);
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\ads\internal\purchase\zzj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */