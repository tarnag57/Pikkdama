package com.google.android.gms.ads.internal.client;

import com.google.android.gms.internal.zzha;

@zzha
public final class zzb
  extends zzn.zza
{
  private final zza zztn;
  
  public zzb(zza paramzza)
  {
    this.zztn = paramzza;
  }
  
  public void onAdClicked()
  {
    this.zztn.onAdClicked();
  }
}


/* Location:              C:\Users\viktor\Documents\DexToJar\dex2jar-2.0\classes-dex2jar.jar!\com\google\android\gms\ads\internal\client\zzb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */